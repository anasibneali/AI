
# Explanation about code running environment for pycharm only:
#          Python 3.7 , It will only support python version 3.7 for pycharm IDE only. you can run it in any
# other version of python but in any other IDE like spyder, jupyter etc. But for pycharm you should have on
# python 3.7 installed.

# Reason:
#        Because in pycharm the integrator of its only supported the given used libraries in python version 3.7

import pandas as pd
import nltk
import numpy as np
import string
from nltk.tokenize import sent_tokenize
from nltk.stem.wordnet import WordNetLemmatizer
from nltk.corpus import stopwords
import re
from textblob import TextBlob
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.ensemble import RandomForestRegressor

def Train_Data(X,Y):
    vectorizer = CountVectorizer(min_df=1)
    X=vectorizer.fit_transform(X).toarray()               #Mapping String tweets on Floating numbers for traning
    model = RandomForestRegressor()                  # Loading Model
    trained_model=model.fit(X,Y)                        # Training
    prob=model.predict(vectorizer.transform(["I need a hug"]).toarray())               # Lets Predict With 2 sentence
    if prob>0:
        print("Positive Sentence")
    else:
        print("Negative Sentence")
    prob=model.predict(vectorizer.transform(["I'm not coming to school"]).toarray())
    if prob>0:
        print("Positive Sentence")
    else:
        print("Negative Sentence")
    return trained_model

def main():
     raw_docs = pd.read_excel("C:/Users/anasa/OneDrive/Documents/AI code/Order (1)/Order/Book1.xlsx")   # Reading the tweets csv dataset
     raw_docs=raw_docs.values
     raw_docs=raw_docs.ravel()                               # Converting the tweets coloum into 1D array

     ## Data Cleansing From Here

     raw_docs = [str(doc).lower() for doc in raw_docs]         # Converting all characters into  lower case
     sent_token = [sent_tokenize(doc) for doc in raw_docs]       # Performing sentence tokenization
     regex = re.compile('[%s]' % re.escape(string.punctuation))

                                                                 # Now By using Tokenized sentence dataset lets remove punctuations
     tokenized_docs_no_punctuation = []
     for review in sent_token:
         new_review = []
         for token in review:
             new_token = regex.sub(u'', token)
             if not new_token == u'':
                 new_review.append(new_token)
         tokenized_docs_no_punctuation.append(new_review)

     print(tokenized_docs_no_punctuation)                                                             # Now lets Perform Cleaning text of stopwords
     tokenized_docs_no_stopwords = []
     for doc in tokenized_docs_no_punctuation:
         new_term_vector = []
         for word in doc:
             if not word in stopwords.words('english'):
                 new_term_vector.append(word)
         tokenized_docs_no_stopwords.append(new_term_vector)
     wordnet = WordNetLemmatizer()

     print(tokenized_docs_no_stopwords)                                                              # Now at last in data cleansing process lets perform Lemmatization so we can retrive missing words from dictionary
     preprocessed_docs = []
     for doc in tokenized_docs_no_stopwords:
         final_doc = []
         for word in doc:
             final_doc.append(wordnet.lemmatize(word))
         preprocessed_docs.append(final_doc)
     preprocessed_docs=np.array(preprocessed_docs)
     print(preprocessed_docs)
     preprocessed_docs = [','.join(doc) for doc in preprocessed_docs]  # Performing some preprocessing in splitted sentences by joinng them
     columns=['Tweets']                                                 # Renaming Comments coloum to Tweets
     Cleaned_Data = pd.DataFrame([preprocessed_docs],columns)
     Cleaned_Data=Cleaned_Data.T
     Cleaned_Data.insert(1,"Sentiments",0)                        # Adding a new Coloum sentiment
     Cleaned_Data['Sentiments'] = Cleaned_Data['Tweets'].apply(lambda tweet: TextBlob(str(tweet)).sentiment.polarity)          # Performing Sentiment analysis using textblob and storing polarity in sentiments coloum
     X=Cleaned_Data["Tweets"]
     Y=Cleaned_Data["Sentiments"]
     Y=np.array(Y)                                  # splitting dataset into X and Y
     X=np.array(X)
     model=Train_Data(X,Y)                 # Calling function for trainnig datset on Random Forest Algorithm
if __name__ == "__main__":
    main()




